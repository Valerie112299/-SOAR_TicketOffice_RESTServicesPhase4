function main() {
                var view = document.getElementById("view");
                var demo = document.getElementById("demo");
                demo.onclick = (e) => html2pdf(view);
            }

