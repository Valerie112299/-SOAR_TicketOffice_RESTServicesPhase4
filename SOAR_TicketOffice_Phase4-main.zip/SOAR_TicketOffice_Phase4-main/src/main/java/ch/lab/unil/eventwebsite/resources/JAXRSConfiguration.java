package ch.lab.unil.eventwebsite.resources;

import javax.ws.rs.ApplicationPath;
import javax.ws.rs.core.Application;

/**
 *
 * @author valer
 */
@ApplicationPath("resources")
public class JAXRSConfiguration extends Application {

}